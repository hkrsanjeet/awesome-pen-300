Compile and run Step1 in VS, copy the payload in Step2, then compile and execute again
